package br.com.consulta;

import java.sql.Date;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Consulta {
    private int id;
    private String paciente_nome;
    private String especialidade;
    private Date data_consulta;
    private Time hora_consulta;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPaciente_nome() {
        return paciente_nome;
    }

    public void setPaciente_nome(String paciente_nome) {
        this.paciente_nome = paciente_nome;
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    public Date getData_consulta() {
        return data_consulta;
    }

    public void setData_consulta(Date data_consulta) {
        this.data_consulta = data_consulta;
    }

    public Time getHora_consulta() {
        return hora_consulta;
    }

    public void setHora_consulta(Time hora_consulta) {
        this.hora_consulta = hora_consulta;
    }
}
