package br.com.consulta;

import br.com.conexao.CriarConexao;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/cadastroConsulta")
public class CadastroConsultaServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
                String nome = request.getParameter("paciente_nome");
        String especialidade = request.getParameter("especialidade");
        String dataConsulta = request.getParameter("data_consulta");
        String horaConsulta = request.getParameter("hora_consulta");
        Connection conn = null;
        try {
           conn = CriarConexao.getConexao();
           ConsultaDAO consultaDAO = new ConsultaDAO(conn);
            String sql = "INSERT INTO consultas (paciente_nome, especialidade, data_consulta, hora_consulta) " +
                        "VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, nome);
            stmt.setString(2, especialidade);
            stmt.setString(3, dataConsulta);
            stmt.setString(4, horaConsulta);
            stmt.executeUpdate();
            stmt.close();
            conn.close();
            response.sendRedirect("sucesso.jsp");
        } catch (Exception e) {
            request.setAttribute("erro", "Erro ao cadastrar consulta: " + e.getMessage());
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }
    }
}