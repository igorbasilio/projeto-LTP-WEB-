package br.com.conexao;

import br.com.conexao.CriarConexao;
import java.sql.Connection;
import java.sql.SQLException;

public class TestConexao {
    public static void main(String[] args) {
        try {
            Connection conn = CriarConexao.getConexao();
            if (conn != null) {
                System.out.println("Conexão bem-sucedida com o banco de dados!");
            } else {
                System.out.println("Falha na conexão com o banco de dados.");
            }
        } catch (SQLException e) {
            System.out.println("Erro ao tentar conectar: " + e.getMessage());
        }
    }
}
