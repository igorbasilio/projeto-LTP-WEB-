package br.com.consulta;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class ConsultaDAO {

    private Connection con;

    public ConsultaDAO(Connection con) {
        this.con = con;
    }

    public void adicionar(Consulta consulta) throws SQLException {
    String sql = "INSERT INTO consulta (paciente_nome, especialidade, data_consulta, hora_consulta) VALUES (?, ?, ?, ?)";
    PreparedStatement stmt = null;
    try {
        stmt = con.prepareStatement(sql);
        stmt.setString(1, consulta.getPaciente_nome());
        stmt.setString(2, consulta.getEspecialidade());
        stmt.setDate(3, new java.sql.Date(consulta.getData_consulta().getTime())); // Para data
        stmt.setTime(4, new java.sql.Time(consulta.getHora_consulta().getTime())); // Para hora
        
        stmt.execute();
    } catch (SQLException e) {
        e.printStackTrace();
        throw new SQLException("Erro ao adicionar consulta", e);
    } finally {
        if (stmt != null) {
            stmt.close();
        }
    }
}

    public void atualizar(Consulta consulta) throws SQLException {
        String sql = "UPDATE consulta SET paciente_nome = ?, especialidade = ?, data_consulta = ?, hora_consulta = ? WHERE id = ?";
        PreparedStatement stmt = null;
        try {
        stmt = con.prepareStatement(sql);
        stmt.setString(1, consulta.getPaciente_nome());
        stmt.setString(2, consulta.getEspecialidade());
        stmt.setDate(3, new java.sql.Date(consulta.getData_consulta().getTime())); // Para data
        stmt.setTime(4, new java.sql.Time(consulta.getHora_consulta().getTime())); // Para hora
            stmt.setInt(5, consulta.getId());

            stmt.execute();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Erro ao atualizar consulta", e);
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    public void deletar(int id) throws SQLException {
    String sql = "DELETE FROM consulta WHERE id = ?";
    PreparedStatement stmt = null;
    try {
        stmt = con.prepareStatement(sql);
        stmt.setInt(1, id);
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
        throw new SQLException("Erro ao deletar consulta", e);
    } finally {
        if (stmt != null) {
            stmt.close();
        }
    }
}


    public List<Consulta> listarTodos() throws SQLException {
        String sql = "SELECT * FROM consulta";
        List<Consulta> consultas = new ArrayList<>();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt = con.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                Consulta consulta = new Consulta();
                consulta.setId(rs.getInt("id"));
                consulta.setPaciente_nome(rs.getString("paciente_nome"));
                consulta.setEspecialidade(rs.getString("especialidade"));
                consulta.setData_consulta(rs.getDate("data_consulta"));
                consulta.setHora_consulta(rs.getTime("hora_consulta"));
                consultas.add(consulta);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Erro ao listar consultas", e);
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
        return consultas;
    }
}
