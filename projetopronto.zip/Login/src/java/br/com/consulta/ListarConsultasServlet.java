package br.com.consulta;

import br.com.conexao.CriarConexao;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// Define a URL para acessar este servlet
@WebServlet("/listarConsultas1")
public class ListarConsultasServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Connection conn = null;
        try {
            // Conexão com o banco de dados
            conn = CriarConexao.getConexao();

            // Criação do objeto DAO e busca das consultas
            ConsultaDAO consultaDAO = new ConsultaDAO(conn);
            List<Consulta> consultas = consultaDAO.listarTodos();  // Usando o método listar() do DAO

            // Atribuindo a lista de consultas ao request para ser utilizada na JSP
            request.setAttribute("consultas", consultas);

            // Redireciona para a página de listagem
            request.getRequestDispatcher("/listarConsultas").forward(request, response);

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("erro.jsp?mensagem=Erro ao carregar consultas.");
        } finally {
            // Fechar a conexão
            try {
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}

