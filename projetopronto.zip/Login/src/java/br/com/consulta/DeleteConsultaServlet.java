package br.com.consulta;

import br.com.conexao.CriarConexao;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "DeleteConsultaServlet", urlPatterns = {"/DeleteConsultaServlet"})
public class DeleteConsultaServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));

        Connection conn = null;
        try {
            conn = CriarConexao.getConexao();

            ConsultaDAO consultaDAO = new ConsultaDAO(conn);
            consultaDAO.deletar(id);  

            response.sendRedirect("consultas.jsp?acao=deletar&mensagem=Consulta deletada com sucesso!");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("consultas.jsp?acao=deletar&mensagem=Erro ao deletar consulta!");
        } finally {
            try {
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
