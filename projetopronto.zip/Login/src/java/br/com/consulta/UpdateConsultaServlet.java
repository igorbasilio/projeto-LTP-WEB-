package br.com.consulta;

import br.com.conexao.CriarConexao;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "UpdateConsultaServlet", urlPatterns = {"/UpdateConsulta"})

public class UpdateConsultaServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public UpdateConsultaServlet() {
        super();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter writer = response.getWriter();

        String idParam = request.getParameter("id");
        String pacienteNomeParam = request.getParameter("paciente_nome");
        String especialidadeParam = request.getParameter("especialidade");
        String dataConsultaParam = request.getParameter("data_consulta");
        String horaConsultaParam = request.getParameter("hora_consulta");

        try {
            int id = Integer.parseInt(idParam);
            Date dataConsulta = Date.valueOf(dataConsultaParam);
            Time horaConsulta = Time.valueOf(horaConsultaParam);

            Connection con = CriarConexao.getConexao();

            Consulta consulta = new Consulta();
            consulta.setId(id);
            consulta.setPaciente_nome(pacienteNomeParam);
            consulta.setEspecialidade(especialidadeParam);
            consulta.setData_consulta(dataConsulta);
            consulta.setHora_consulta(horaConsulta);

            ConsultaDAO dao = new ConsultaDAO(con);
            dao.atualizar(consulta);
            request.setAttribute("id", consulta.getId());
            request.setAttribute("paciente_nome", consulta.getPaciente_nome());
            request.setAttribute("especialidade", consulta.getEspecialidade());
            request.setAttribute("data_consulta", consulta.getData_consulta().toString());
            request.setAttribute("hora_consulta", consulta.getHora_consulta().toString());

            request.getRequestDispatcher("consultaAtualizada.jsp").forward(request, response);

        } catch (SQLException e) {
            e.printStackTrace();
            writer.println("Erro ao atualizar consulta: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
            writer.println("Erro nos dados enviados: " + e.getMessage());
        }
    }
}
